#include <stdlib.h>
#include <stdio.h>
void welcome() {
const char* str = "Welcome to join Embedded Studio!";
puts(str);
exit(EXIT_SUCCESS);
}
int main () {
welcome();
}


